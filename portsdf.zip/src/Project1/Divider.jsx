import React from "react";
import styles from "./Desktop8.module.css";

function Divider() {
  return <hr className={styles.divider} />;
}

export default Divider;
