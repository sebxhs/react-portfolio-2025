import React from "react";

function Divider({ className }) {
  return <hr className={className} />;
}

export default Divider;
